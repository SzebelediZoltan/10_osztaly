x = float(input("x: "))
y = float(input("y: "))

if x == 0 or y == 0:
    if x == 0 and y == 0:
        print("Origó")
    else:
        print("Nem esik síknegyedre")
elif x > 0 and y > 0:
    print(1)
elif x > 0 and y < 0:
    print(4)
elif x < 0 and y > 0:
    print(2)
else:
    print(3)
