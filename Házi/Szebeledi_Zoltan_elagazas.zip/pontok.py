csapat1 = input("Első csapat: ")
pontok1 = float(input("Pontok: "))
csapat2 = input("Második csapat: ")
pontok2 = float(input("Pontok: "))

if pontok1 == pontok2:
    print("Döntetlen")
elif pontok1 > pontok2:
    print(csapat1, "nyert")
else:
    print(csapat2, "nyert")
